/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maintenance;

import entities.Garageentitie;
import services.Rdv;
import services.garage;
import services.service;
import entities.Rdventitie;
import entities.Serviceentitie;
import java.sql.Date;
import doryan.windowsnotificationapi.fr.Notification;
/**
 *
 * @author walid
 */
public class Maintenance {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //maintenance c = new ma3intenace(5,null,'2020-01-10',1,0);
        //clubs c2 = new clubs (6,"hello","world");
        
        Menu menu = new Menu();
        menu.runMenu();
        
        /*Garageentitie g = new Garageentitie (1,2,"salah mecanicien","3 rue palestien");
        Rdventitie r =new Rdventitie (3,4,5,6,Date.valueOf("2019-06-5"),"yfyf");
        Serviceentitie s =new Serviceentitie  (7,"lavage2");
        
        
        
        //Rdv srv1=new Rdv();
        garage srv2=new garage();
        service srv3=new service();
       srv1.create_rdv(r);
       rv2.create_garage(g);srv2.create_garage(g);
       srv3.create_service(s);
        System.out.println("---------Affichage----------------------");
        srv1.display_rdv();
        srv2.display_garage();
        srv3.display_service();
        System.out.println("---------Modification--------------------");
       srv1.edit_rdv(r, Date.valueOf("2020-02-02"));
       srv2.edit_garage(g, "lavage3");
        System.out.println("---------Après_modification--------------");
        srv1.display_rdv();
        srv2.display_garage();

        System.out.println("--------Supprission---------");
        srv1.remove_rdv(r);
        srv2.remove_garage(g);
        srv3.remove_service(s);

    
   */ }
    
}
